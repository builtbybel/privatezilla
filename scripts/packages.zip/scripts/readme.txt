This feature enhances Spydish and adds several community powered PowerShell script files which allows to:
- Uninstall preinstalled apps (debloating)
- Disable various Windows 10 telemetry features
- Block Microsoft telemetry IPs via Windows Firewall and hosts file
- Remove OneDrive integration
- Remove Windows Defender 
- Block telemetry of third-party apps, e.g. CCleaner, Firefox, Microsoft Office
- and many more

These are third party script files and the author of this app does not guarantee that they will also work for you. Every script contains a link to the original author.  
If you don't understand the scripts and know what they do, you should also NOT execute them.

You will also find bundled script files (called templates) written by the author of this app. 
These allow you to automate numerous processes, e.g. you could use the "templateBasicPrivacy" to handle the whole category Policies > Privacy in Spydish. Templates and script file written by the author of Spydish will get support on GitHub https://github.com/mirinsoft/spydish/issues

NOTE: If you no longer wish to see this notice, then remove the "readme.txt" in the scripts directory.