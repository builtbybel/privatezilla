--------------------------------------------------------------------------------
This package is ONLY compatible with version 0.41 of Privatezilla and higher!
You can download the latest version here: https://github.com/builtbybel/privatezilla/releases
--------------------------------------------------------------------------------

This feature enhances Privatezilla and adds several community powered PowerShell script files which allows to:
- Uninstall preinstalled apps (debloating)
- Reinstalling all default apps
- Disable various Windows 10 telemetry features
- Block Microsoft telemetry IPs via Windows Firewall and hosts file
- Remove OneDrive integration
- Remove Windows Defender 
- Block telemetry of third-party apps, e.g. CCleaner, Firefox, Microsoft Office
- and many more

These are third party script files and the author of this app does not guarantee that they will also work for you. Each script contains a link to the original author. If you don't understand the scripts, then you should also NOT execute them.

You will also find bundled script files (called templates) written by the author of this app. These files allow you to automate numerous processes, e.g. you could use the "Telemetry of third-party apps (Template)" to block and disable telemetry features of apps such as CCleaner, Firefox, Google etc.

NOTE: If you no longer wish to see this notice, then remove the "readme.txt" in the scripts directory.
